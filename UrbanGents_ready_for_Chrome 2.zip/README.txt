URBANGENTS — READY WEBSITE

1. Upload index.html to a static website host.
2. It opens in Chrome using the published web address.
3. WhatsApp orders go to +977 9768518216.
4. You can add product names, prices and photos from the Seller section.

IMPORTANT:
This version is a static site. Its product list is saved in each browser separately.
For a true shared store (you add a product on your phone and every supplier sees it), a shared database + secure admin login is required.
